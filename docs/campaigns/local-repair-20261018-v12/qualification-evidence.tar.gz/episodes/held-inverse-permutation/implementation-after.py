def inverse_permutation(values, size):
    return list(values)
