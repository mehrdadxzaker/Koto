def prefix_products(values):
    if not values:
        return []
    result = []
    product = 1
    for num in values:
        product *= num
        result.append(product)
    return result
