def rotate_left(items, steps):
    if not items:
        return []
    n = len(items)
    effective_steps = steps % n
    return items[effective_steps:] + items[:effective_steps]
