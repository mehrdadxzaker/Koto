def step_traffic(state):
    if not isinstance(state, dict):
        raise ValueError('Invalid state')
    phase = state.get('phase')
    cycles = state.get('cycles')
    if phase not in ('red', 'green', 'amber'):
        raise ValueError('Invalid phase')
    if not isinstance(cycles, int) or isinstance(cycles, bool) or cycles < 0:
        raise ValueError('Invalid cycles')
    new_cycles = cycles + 1 if phase == 'amber' else cycles
    next_phase = {'red': 'green', 'green': 'amber', 'amber': 'red'}[phase]
    result = dict(state)
    result['phase'] = next_phase
    result['cycles'] = new_cycles
    return result
