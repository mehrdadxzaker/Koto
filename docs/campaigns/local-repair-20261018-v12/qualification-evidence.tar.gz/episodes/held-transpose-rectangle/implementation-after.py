def transpose(rows):
    if not rows:
        return []
    # Check if all rows have the same length
    row_length = len(rows[0])
    for row in rows:
        if len(row) != row_length:
            raise ValueError("Rows must have the same length")
    # Transpose the matrix
    transposed = []
    for i in range(row_length):
        new_row = []
        for row in rows:
            new_row.append(row[i])
        transposed.append(new_row)
    return transposed
