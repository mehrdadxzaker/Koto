class Counter:
    def __init__(self):
        self.value = 0
    def increment(self, step=1):
        # Ensure step is a strict positive integer (bool is invalid)
        if not isinstance(step, int) or isinstance(step, bool) or step <= 0:
            raise ValueError("step must be a strict positive integer")
        self.value += step
        return self.value
