def rot13(text):
    result = ""
    for char in text:
        if 'a' <= char <= 'z':
            # Rotate lowercase letter
            rotated = ord('a') + (ord(char) - ord('a') + 13) % 26
            result += chr(rotated)
        elif 'A' <= char <= 'Z':
            # Rotate uppercase letter
            rotated = ord('A') + (ord(char) - ord('A') + 13) % 26
            result += chr(rotated)
        else:
            # Preserve non-ASCII letters, digits, punctuation, whitespace
            result += char
    return result
