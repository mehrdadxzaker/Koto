def triangular(n):
    if not isinstance(n, int) or isinstance(n, bool):
        raise ValueError("n must be a nonnegative integer excluding bool")
    if n < 0:
        raise ValueError("n must be nonnegative")
    return n * (n + 1) // 2
