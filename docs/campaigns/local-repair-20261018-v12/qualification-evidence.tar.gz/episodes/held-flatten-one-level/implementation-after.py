def flatten_once(values):
    return [item for value in values for item in (value if isinstance(value, list) else [value])]
