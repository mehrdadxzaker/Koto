def register_name(state, name):
    if not isinstance(name, str):
        raise ValueError("name must be a string")
    normalized_name = name.strip()
    if not normalized_name:
        raise ValueError("name cannot be empty or whitespace only")
    if 'names' not in state:
        state = dict(state)
        state['names'] = []
    else:
        state = dict(state)
    if normalized_name in state['names']:
        raise ValueError(f"name '{normalized_name}' already registered")
    state['names'].append(normalized_name)
    return state
