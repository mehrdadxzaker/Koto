def strip_prefix(text, prefix):
    if not prefix:
        return text
    if text.startswith(prefix):
        return text[len(prefix):]
    return text
