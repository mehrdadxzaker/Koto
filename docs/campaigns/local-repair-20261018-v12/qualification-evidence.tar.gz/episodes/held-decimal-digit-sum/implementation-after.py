def digit_sum(value):
    total = 0
    n = abs(value)
    while n:
        total += n % 10
        n //= 10
    return total
