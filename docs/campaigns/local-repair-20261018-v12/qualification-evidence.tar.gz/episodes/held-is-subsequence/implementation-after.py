def is_subsequence(needle, haystack):
    """
    Check if needle is a subsequence of haystack.
    Returns True if all characters in needle appear in haystack in order,
    with arbitrary characters skipped. Each haystack position can be used only once.
    Empty needle is always a subsequence.
    Comparison is case-sensitive and exact for Unicode characters.
    """
    if not needle:  # Empty needle is always a subsequence
        return True
    
    needle_ptr = 0
    haystack_ptr = 0
    
    while needle_ptr < len(needle) and haystack_ptr < len(haystack):
        if needle[needle_ptr] == haystack[haystack_ptr]:
            needle_ptr += 1
        haystack_ptr += 1
    
    return needle_ptr == len(needle)
