def mask_digits(text, mask):
    if not isinstance(mask, str) or len(mask) != 1:
        raise ValueError("mask must be a string of exactly one character")
    return ''.join(mask if c.isdigit() and ord(c) < 128 else c for c in text)
